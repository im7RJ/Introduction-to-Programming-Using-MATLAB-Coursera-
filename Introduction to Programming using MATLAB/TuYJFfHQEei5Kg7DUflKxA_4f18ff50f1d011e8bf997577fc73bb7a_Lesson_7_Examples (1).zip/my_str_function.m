function out = my_str_function(in)
out = in(end:-1:1);
